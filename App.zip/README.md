# Facebook Interaction Predictor

This Streamlit app predicts the total number of interactions on a Facebook post using metrics like reach, likes, shares, and post type.

## How to Use
1. Fill in the input fields.
2. Click "Predict" to see the estimated interactions.

Model trained using scikit-learn.
